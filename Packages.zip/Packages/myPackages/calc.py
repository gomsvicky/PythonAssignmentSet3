
import math


def add(a, b):
    result = (a + b)
    print("Sum of two numbers : ", result)


def sub(a, b):
    result = a- b
    print("Subtract of two numbers : ", result)


def mul(a, b):
    result = a * b
    print("Multiplication of two numbers : ", result)


def div(a, b):
    result = a / b
    print("Division of two numbers : ", result)


def sqr(a):
    result = math.sqrt(a)
    print("Square root of number : ", result)


def floordiv(a, b):
    result = a // b
    print("Floor division of two numbers : ", result)


def mod(a, b):
    result = a % b
    print("Modules of two numbers : ", result)


def prime(num):
    if num > 1:
        for i in range(2, num):
            if num % i == 0:
                print(num, " number is not a prime number")
                break
        else:
            print(num, " number is prime number")

def fib(num):
    print("Fibanocci series for ", num)
    a = 0
    b = 1
    if num <= 0:
        print("please enter positive number")
    elif num == 1:
        print("Fibonacci series:", a)
    elif num == 2:
        print(a)
        print(b)
    else:
        print(a)
        print(b)

    while (num > 2):
        numnext = a + b
        if numnext < 100:
            print(numnext)
            a = b
            b = numnext
            num = num - 1
        else:
            break
