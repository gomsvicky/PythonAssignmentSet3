#stringop.py
def sorting():
    list1 = [55,33,99,22,78]
    new_list = []
    while list1:
        minimum = list1[0]
        for x in list1:
            if x < minimum:
                minimum = x
        new_list.append(minimum)
        list1.remove(minimum)

    print("After sorting the entered elements : ", new_list)


def reverse(txt):
    txt1 = txt[::-1]
    print("Given string has been reversed")
    print(txt1)


def bsearch(num):
    list1 = [1,2,3,4,5]
    found = 0
    for j in list1:
        if j == num:
            print("success")
            found = 1
            break
    if found == 0:
        print("un successful search")