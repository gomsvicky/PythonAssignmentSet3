txt = 'it\'s fine'
print("single quotes operator : ", txt)
txt = "its \\ fine"
print("back slash ", txt)
txt = "Good \n Morning"
print("new line : ", txt)
txt ="Good \r morning"
print("carriage return  : ", txt)
txt ="Good \t morning"
print("Tab  : ", txt)
txt ="Good \b morning"
print("back space  : ", txt)
txt ="Good \100 morning"
print("Octal value  : ", txt)
txt ="Good \x45 morning"
print("Hexa decimal : ", txt)