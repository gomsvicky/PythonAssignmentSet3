tup1 = (2, 3, 4)
tup2 = (6, 8, 9)
list1 = [22, 55, 77, 88]
print("Max value of tup1 is ", max(tup1), " and tup2 is ", max(tup2))
print("Min value of tup1 is ",  min(tup1), " and tup2 is", min(tup2))
print("length of tup1 is ", len(tup1), " and tup2 is ", len(tup2))
print("converts a list to tuple :", tuple(list1))
