text = "this is string example....wow!!!"
text1 = text.encode()

print("Encoded String: ", text1)
print("Decoded String: ", text1.decode())