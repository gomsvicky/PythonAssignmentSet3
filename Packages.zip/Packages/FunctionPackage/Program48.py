import math
def sum(a, b):
    result = (a + b)
    print("Sum of two numbers : ", result)


def sub(a, b):
    result = a- b
    print("Subtract of two numbers : ", result)


def mul(a, b):
    result = a * b
    print("Multiplication of two numbers : ", result)


def div(a, b):
    result = a / b
    print("Division of two numbers : ", result)


def sqr(a):
    result = math.sqrt(a)
    print("Square root of number : ", result)


def substr(string, spliter):
    result = string.split(spliter, 10)
    print("substring is ", result)


a = int(input("Enter first number :"))
b = int(input("Enter second number :"))

sum(a, b)
sub(a, b)
mul(a, b)
div(a, b)
sqr(a)

string = "Pack: My: Box: With: Good: Food"
spliter = ":"
substr(string, spliter)