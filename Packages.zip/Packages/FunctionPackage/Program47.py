def exd(tup1, list1):
    tup1 = list(tup1)
    result = tup1 + list1
    result = tuple(result)
    print("After extending tuple with a list :", result)


t = (1, 2, 3, 4)
l = [11, 22, 33, 44]
print("Tuple elements :", t)
print("List elements :", l)
exd(t, l)
