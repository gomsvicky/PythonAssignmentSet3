print("Enter a number to do all basic functions :")
n = int(input())
add = lambda a: a + 10
print("Addition of number with 10 : ", add(n))
sub = lambda a: a - 10
print("Subtraction of number with 10 : ", sub(n))
mul = lambda a: a + 10
print("Multiplication of number with 10 : ", mul(n))
div = lambda a: a / 10
print("Divison of number with 10 : ", div(n))
mod = lambda a: a % 10
print("Modulus of number with 10 : ", mod(n))
fdiv = lambda a: a // 10
print("Floor Divison of number with 10 : ", fdiv(n))
