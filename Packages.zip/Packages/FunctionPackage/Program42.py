def fib(nterms):
  "This generates a fibonacci series"
  a = 0
  b = 1
  if nterms <= 0:
    print("please enter positive number")
  elif nterms == 1:
    print("Fibonacci series:\n", a)
  elif nterms == 2:
    print("Fibonacci series:\n", a)
    print(b)
  else:
    print("Fibonacci series :\n", a)
    print(b)
    while(nterms > 2):
      numnext = a+b
      print(numnext)
      a = b
      b = numnext
      nterms = nterms-1
# Now you can call fib function
n = int(input("Enter the no of terms :"))
fib(n)