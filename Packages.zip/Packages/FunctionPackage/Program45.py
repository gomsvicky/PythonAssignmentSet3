def palidrome(txt):
#txt = "malayalam"
    txt1 = txt[::-1]
    if txt == txt1:
        print("given text is Palindrome ")
    else:
        print("given text is not a Palindrome ")

txt = input("enter a text :")
palidrome(txt)