def big4(list1):
    max1 = list1[0]
    for x in list1:
        if x > max1:
            max1 = x
    print("Biggest number is ", max1)

print("****Default arguments are passed***\n elements are [4, 3, 8, 2]")
big4([4, 3, 8, 2])
num = int(input("Enter number of elements in list: "))
list1 = []
for i in range(1, num + 1):
    ele = input("Enter elements: ")
    list1.append(ele)
print("Entered elements ", list1)
print("*****Arguments are passed by user****")
big4(list1)
