import calendar
print("2016 calendar with width 10")
print(calendar.calendar(2016, 1, 1, 10))
print("leap days between the years 1980 to 2025", calendar.leapdays(1980, 2025))
print("2020 is leap year ?", calendar.isleap(2020))
print("print september month ", calendar.month(2016, 9, 1, 1))