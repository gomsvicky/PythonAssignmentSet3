import time
import calendar
time1 = time.asctime()
print("*******Current time********** \n", time1)
month = calendar.month(2020, 6)
print("********Current month calendar********** \n", month)