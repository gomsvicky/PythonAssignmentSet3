import glob
totalCount = 0
for i in glob.glob("*.txt"):
    myfile = open(i, "r")
    list1 = myfile.read().split()
    if "Treasure" in list1:
        print("File name:", i, "\nCount of word Treasure in current file:", list1.count("Treasure"))
        totalCount += list1.count("Treasure")
    else:
        print("File name:", i, "\nCount of word Treasure in current file:", 0)
    myfile.close()
print("Total count of Treasure word in all the files:", totalCount)
