fo = open("test.txt", "r")
print("test file only to read \n", fo.read())
fo.close()

fo = open("first.txt", "w")
fo.writelines("1.Welcome \n 2.to Python!!\n 3.Learn more \n 4.and use more \n 5.the end!!")
fo.close()

fo = open("first.txt", "a+")
fo.writelines("\n 6.Open file \n 7.in Append mode \n 8.and add 5 lines\n 9.of text \n 10.into it")
fo.close()

fo = open("first.txt", "r")
print("first file only to read \n", fo.read())
fo.close()