fo = open("test.txt", "r")
p = 0
print("*****it will print 10 position characters till file end******")
while(True):
    a = fo.read(10)
    if not a:
        break
    else:
        print(a)
        p += 10
        print("position", p)
fo.close()

fo = open("test.txt", "r")
p = 0
while(p < 100):
    a = fo.read(10)
    if not a:
        break
    else:
        print(a)
        p += 10
        print("position=", p)
fo.seek(0, 0)
print("***********The position is changed to 0 so it will start from first line********")
line = fo.readline()
print("Read Line: %s" % (line))
fo.close()

print("************Print from 6th line of the file**********")

fo = open("test.txt", "r")
for i in range(5):
    fo.readline()
for line in fo:
    print("line=", line)
fo.close()


