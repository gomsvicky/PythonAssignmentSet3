print("*****Reverse lines alone*****")
fo = open("output1.txt", "w")
with open("test.txt", "r") as myfile:
    data = myfile.readlines()
data1 = data[::-1]
fo.writelines(data1)
print("Check the output")
fo.close()

print("****reverse complete characters*****")
fo = open("output.txt", "w")
with open("test.txt", "r") as myfile:
    data = myfile.read()
data1 = data[::-1]
fo.write(data1)
print("Check the output")
fo.close()
